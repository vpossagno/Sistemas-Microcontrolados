//UTFPR
//Sistemas Microcontrolados - ET77C-S23-B
//Professor: Delvanei
//Vinicios Pereira Possagno RA: 1608002 
//Lucas Cheslak Rogge RA: 2029189

//Projeto Semanal 2

//Este projeto foi realizado por cima do c�digo EdgeInterrupt.c disponibilizado pelo professor Valvano

// EdgeInterrupt.c
// Runs on LM4F120 or TM4C123
// Request an interrupt on the falling edge of PF4 (when the user
// button is pressed) and increment a counter in the interrupt.  Note
// that button bouncing is not addressed.
// Daniel Valvano
// May 3, 2015

/* This example accompanies the book
   "Embedded Systems: Introduction to ARM Cortex M Microcontrollers"
   ISBN: 978-1469998749, Jonathan Valvano, copyright (c) 2015
   Volume 1, Program 9.4
   
   "Embedded Systems: Real Time Interfacing to ARM Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2014
   Volume 2, Program 5.6, Section 5.5

 Copyright 2015 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */


#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
#include "../inc/EdgeInterruptPortF.h"
#include "../inc/CortexM.h"
#include "../inc/PLL.h"
#include "../inc/TExaS.h"

#define SYSCTL_RCGC2_R          (*((volatile unsigned long *)0x400FE108))
#define GPIO_PORTD_DATA_R       (*((volatile unsigned long *)0x400073FC))
#define GPIO_PORTD_DIR_R        (*((volatile unsigned long *)0x40007400))
#define GPIO_PORTD_AFSEL_R      (*((volatile unsigned long *)0x40007420))
#define GPIO_PORTD_DEN_R        (*((volatile unsigned long *)0x4000751C))
#define GPIO_PORTD_AMSEL_R      (*((volatile unsigned long *)0x40007528))
#define GPIO_PORTD_PCTL_R       (*((volatile unsigned long *)0x4000752C))

//********************************************************************************
// debuging profile, pick up to 7 unused bits and send to Logic Analyzer
// TExaSdisplay logic analyzer shows 5 bits 0,0,PF4,PF3,PF2,PF1,PF0 
// edit this to output which pins you use for profiling
// you can output up to 7 pins
// use for debugging profile

void LogicAnalyzerTask(void){
  UART0_DR_R = 0x80|GPIO_PORTF_DATA_R; // sends at 10kHz
}
void ScopeTask(void){  // called 10k/sec
  UART0_DR_R = (ADC1_SSFIFO3_R>>4); // send ADC to TExaSdisplay
}

unsigned long volatile delay;

//use for debugging profile
#define PF1       (*((volatile uint32_t *)0x40025008))		//LEDS e PD3
#define PF2       (*((volatile uint32_t *)0x40025010))
#define PF3       (*((volatile uint32_t *)0x40025020))
#define PD3    		(*((volatile uint32_t *)0x40007020))		//PD3 desligado � zero---PD3 ligado � 8
	
// global variable visible in Watch window of debugger
// increments at least once per button press
volatile uint32_t cont = 0;
unsigned long SW1,SW2,aux1,aux2=0;												// Vari�veis auxiliares

void atraso(void)
	{
		unsigned long volatile time;
		time = 0.9096044221*727240*40/91; // 0.2 sec
		while(time){
			time--;
		}
}

void EdgeCounterPortF_Init(void){                          
  SYSCTL_RCGCGPIO_R |= 0x00000020; // (a) activate clock for port F
  cont = 0;             					// (b) initialize counter
  GPIO_PORTF_LOCK_R = 0x4C4F434B;   // 2) unlock GPIO Port F
  GPIO_PORTF_CR_R = 0x1F;           // allow changes to PF4-0
  GPIO_PORTF_DIR_R |=  0x0E;    // output on PF3,2,1 
  GPIO_PORTF_DIR_R &= ~0x11;    // (c) make PF4,0 in (built-in button)
  GPIO_PORTF_AFSEL_R &= ~0x1F;  //     disable alt funct on PF4,0
  GPIO_PORTF_DEN_R |= 0x1F;     //     enable digital I/O on PF4   
  GPIO_PORTF_PCTL_R &= ~0x000FFFFF; // configure PF4 as GPIO
  GPIO_PORTF_AMSEL_R = 0;       //     disable analog functionality on PF
  GPIO_PORTF_PUR_R |= 0x11;     //     enable weak pull-up on PF4
  GPIO_PORTF_IS_R &= ~0x10;     // (d1) PF4 is edge-sensitive
  GPIO_PORTF_IBE_R &= ~0x10;    //     PF4 is not both edges
  GPIO_PORTF_IEV_R &= ~0x10;    //     PF4 falling edge event
	GPIO_PORTF_PUR_R |= 0x11;     //     enable weak pull-up on PF4
  GPIO_PORTF_IS_R |= 0x10;     // (d2) PF0 is level-sensitive
  GPIO_PORTF_IBE_R &= ~0x10;    //     PF0 is not both edges
  GPIO_PORTF_IEV_R |= 0x10;    //     PF0 high level event
  GPIO_PORTF_ICR_R = 0x10;      // (e) clear flag4
  GPIO_PORTF_IM_R |= 0x10;      // (f) arm interrupt on PF4 *** No IME bit as mentioned in Book ***
  NVIC_PRI7_R = (NVIC_PRI7_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  NVIC_EN0_R = 0x40000000;      // (h) enable interrupt 30 in NVIC
}
void GPIOPortF_Handler(void){		//Rotina de interrup��o
  GPIO_PORTF_ICR_R = 0x10;      // acknowledge flag4
  SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1
	SW2 = ~GPIO_PORTF_DATA_R&0x01; //L� PF0 e atribui em SW2
	
	
	if(cont==0 && SW1==0x00)			//estado zero
		{
				while(cont==0 && SW1==0x00)			//Caso contador e SW1 sejam iguais a zero
				{
					PD3=0;												//PD3 desativado
					GPIO_PORTF_DATA_R=0x00;				//LEDs apagados
					SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1
				}
				cont++;														//contador incrementa quando SW1=0x01, saindo do loop
		}
		if(cont==1 && SW1==0x00)			//estado 1
		{
				PD3=0;														//PD3 desativado
				GPIO_PORTF_DATA_R=0x00;						//LEDs apagados
				while(SW1==0x00)									//Quando SW1 � despressionado
				{
					GPIO_PORTF_DATA_R=0x04;					//LED azul acionado
					atraso();
					GPIO_PORTF_DATA_R=0x00;					//LEDS apagados
					atraso();
					SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1
				}
				cont++;
		}
		if(cont==2 && SW1==0x00)		//estado 2
		{
			SW2 = ~GPIO_PORTF_DATA_R&0x01; //L� PF0 e atribui em SW2
			if(SW2==0x01)										//Caso SW2 esteja em n�vel alto, contador recebe valor 4
			{
				cont=4;
			}
			else
				cont=3;												//Caso SW2 esteja em n�vel baixo, contador recebe valor 3
			SW2 = ~GPIO_PORTF_DATA_R&0x01; //L� PF0 e atribui em SW2
			SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1
		}
		if(cont==3 && SW1==0x00)		//estado 3
		{
			GPIO_PORTF_DATA_R=0x00;					//Desliga LEDS
			for(aux1=0;aux1<5;aux1++)				//Pisca LED verde 5 vezes
			{
				GPIO_PORTF_DATA_R=0x00;
				atraso();
				GPIO_PORTF_DATA_R=0x08;
				atraso();
			}
			SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1
			cont=1;													//Quando estado 3 � encerrado, retorna ao estado 1
		}
		if(cont==4 && SW1==0x00)		//estado 4
		{
			GPIO_PORTF_DATA_R=0x00;				//LEDs apagados
			for(aux1=0;aux1<2;aux1++)			//LED vermelho pisca 2 vezes
			{
				GPIO_PORTF_DATA_R=0x00;
				atraso();
				GPIO_PORTF_DATA_R=0x02;
				atraso();
			}
			atraso();
			atraso();
			atraso();
			GPIO_PORTF_DATA_R=0x00;			 //atraso e apagamento dos LEDs para EVIDENCIAR TROCA DE ESTADO
			atraso();
			atraso();
			atraso();
			while(SW1==0)
				SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1
			cont++;
		}
		//estado 5
		if((cont==5 || cont ==6) && SW1==0x00 && aux2<2)		//estado 5 ocorre duas vezes em sequencia
		{
			GPIO_PORTF_DATA_R=0x00;														//apaga LEDs
				while(SW1==0x00)																//Ap�s despressionar SW1 LED vermelho pisca em 2,5 Hz
				{
					GPIO_PORTF_DATA_R=0x02;
					atraso();
					GPIO_PORTF_DATA_R=0x00;
					atraso();
					SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1
				}

			aux2++;
			cont++;	
		}
		aux2=0;
		if(cont==7 && SW1==0x00) //estado 6						//PD3 ativado com valor 8 (1000)b
		{			
			PD3=~PD3;
				for(aux1=0;aux1<4;aux1++)									//LEDs piscam em ordem 4 vezes
				{
					GPIO_PORTF_DATA_R=0x00;
					atraso();
					GPIO_PORTF_DATA_R=0x02;
					atraso();
					GPIO_PORTF_DATA_R=0x04;
					atraso();
					GPIO_PORTF_DATA_R=0x08;
					atraso();
				}
		SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1
		cont++;
		}
		if (cont==8)																	//Retorna ao estado zero
			cont=0;
		}

// Color    LED(s) PortF
// dark     ---    0
// red      R--    0x02
// blue     --B    0x04
// green    -G-    0x08
// yellow   RG-    0x0A
// sky blue -GB    0x0C
// white    RGB    0x0E
// pink     R-B    0x06

//Rotinha principal
int main(void){
// pick one of the following three lines, all three set PLL to 80 MHz
  //PLL_Init(Bus80MHz);              // 1) call to have no TExaS debugging
  //TExaS_SetTask(&LogicAnalyzerTask); // 2) call to activate logic analyzer
  //TExaS_SetTask(&ScopeTask);       // or 3) call to activate analog scope PD3
  SYSCTL_RCGC2_R |= 0x08;           // Port D clock
  delay = SYSCTL_RCGC2_R;           // wait 3-5 bus cycles
	GPIO_PORTD_DIR_R |= 0x08;         // PD3 output
	GPIO_PORTD_DEN_R |= 0x08;         // enable PD3
	
  EdgeCounterPortF_Init();           // initialize GPIO Port F interrupt
  EnableInterrupts();
  while(1){
	}	
}
