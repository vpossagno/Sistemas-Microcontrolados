/*
UNIVERSIDADE TECNOL�GICA FEDERAL DO PARAN�
SISTEMAS MICROCONTROLADOS - ET77C-S23-B
PROFESSOR: DELVANEI G. BANDEIRA JR.
Alunos:
VINICIOS PEREIRA POSSAGNO RA: 1608002
LUCAS CHESLAK ROGGE RA: 2029189

PROJETO 1 - M�QUINA DE ESTADOS
*/

//Este projeto foi realizado por cima do c�digo EdgeInterrupt.c disponibilizado pelo professor Valvano

// EdgeInterrupt.c
// Runs on LM4F120 or TM4C123
// Request an interrupt on the falling edge of PF4 (when the user
// button is pressed) and increment a counter in the interrupt.  Note
// that button bouncing is not addressed.
// Daniel Valvano
// May 3, 2015

/* This example accompanies the book
   "Embedded Systems: Introduction to ARM Cortex M Microcontrollers"
   ISBN: 978-1469998749, Jonathan Valvano, copyright (c) 2015
   Volume 1, Program 9.4
   
   "Embedded Systems: Real Time Interfacing to ARM Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2014
   Volume 2, Program 5.6, Section 5.5

 Copyright 2015 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

#include "tm4c123gh6pm.h" //possui os defines j� pre-estabelecidos
#include "Systick.h"
#include <stdint.h>


//********************************************************************************
// debuging profile, pick up to 7 unused bits and send to Logic Analyzer
// TExaSdisplay logic analyzer shows 5 bits 0,0,PF4,PF3,PF2,PF1,PF0 
// edit this to output which pins you use for profiling
// you can output up to 7 pins
// use for debugging profile

void LogicAnalyzerTask(void){
  UART0_DR_R = 0x80|GPIO_PORTF_DATA_R; // sends at 10kHz
}
void ScopeTask(void){  // called 10k/sec
  UART0_DR_R = (ADC1_SSFIFO3_R>>4); // send ADC to TExaSdisplay
}

#define PF1 (*((volatile uint32_t *)0x40025008))					//LEDS e PD3
#define PF2 (*((volatile uint32_t *)0x40025010))
#define PF3 (*((volatile uint32_t *)0x40025020))
#define PD3 (*((volatile uint32_t *)0x40007020))					//PD3 desligado � zero---PD3 ligado � 8
#define SW2 (*((volatile uint32_t *)0x40025001))
#define SW1 (*((volatile uint32_t *)0x40025040))
	
unsigned long aux1=0;						// Variavel auxiliar
static uint32_t cont=0; 				//vari�vel contador

void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void); // Enable interrupts
void WaitForInterrupt(void); // low power mode

void Delay_Variavel(float var)
{
		unsigned long volatile time;
		time = var*4.546467168*727240*20/91; // Express�o para gerar delay com valor "var" em segundos
	while(time){													//Ex: se chamda Delay_Variavel(10) o delay ser� de 10 segundos
			time--;
		}
}

void PortD_Init(void){ 
 SYSCTL_RCGCGPIO_R |= 0x00000008; // (a) activate clock for port D 
 // (b) initialize counter
 GPIO_PORTD_LOCK_R = 0x4C4F434B; // 2) unlock GPIO Port D
 GPIO_PORTD_CR_R = 0x1F; // allow changes to PD
 GPIO_PORTD_DIR_R |= 0x08; // output on PD3
 GPIO_PORTD_AFSEL_R &= ~0x1F; // disable alt funct on PD
 GPIO_PORTD_DEN_R |= 0x1F; // enable digital I/O on PD3
 GPIO_PORTD_PCTL_R &= ~0x000FFFFF; // configure PD as GPIO
 GPIO_PORTD_AMSEL_R = 0; // disable analog functionality on PD
}

void PortF_Init(void){
 volatile unsigned long delay;
 SYSCTL_RCGC2_R |= 0x00000020; // F clock
 delay = SYSCTL_RCGC2_R; // delay 
 GPIO_PORTF_LOCK_R = 0x4C4F434B; // unlock PortF PF0 
 GPIO_PORTF_CR_R = 0x1F; // allow changes to PF4-0 
 GPIO_PORTF_AMSEL_R = 0; // disable analog functionality on PORTF
 GPIO_PORTF_PCTL_R = 0x00000000; // configure PORTF as GPIO
 GPIO_PORTF_DIR_R |= 0x0E; // make PF0, PF4 input, PF1-PF3 output
 GPIO_PORTF_AFSEL_R &= ~0x1F; // disable alt funct 
 GPIO_PORTF_PUR_R = 0x11; // enable weak pull-up on PF4 and PF0
 GPIO_PORTF_DEN_R |= 0x1F; // enable digital I/O
}

void GPIOPortF_Handler(void){		//Rotina de interrup��o para inicializa��o a qualquer momento que SW1 seja pressionado
  GPIO_PORTF_ICR_R = 0x10;      // acknowledge flag4
				if(cont==0&&SW1==0x00)					//Caso SW1 ativa cont � aumentado e c�digo come�a
					cont++;		
}


//Rotina principal
int main(void){
	volatile unsigned long delay;
	PortF_Init(); 											// initialize PortF
	PortD_Init();												//inicializa PortD

	GPIOPortF_Handler();

	EnableInterrupts();								//Habilita interrup��o
  while(1){
		switch(cont){
		//Estado zero						***TUDO DESLIGADO - STAND-BY - LIGA APENAS COM ACIONAMENTO DE SW1***
		case 0:
				PF1=0x00;
				PF2=0x00;
				PF3=0x00;
				PD3=0x00;
				GPIOPortF_Handler();
			break;
		//Estado 1						***LED AZUL PISCA COM FREQ 2,5 HZ***
		case 1:
				PF1=0x00;
				PF3=0x00;
				PD3=0x00;
				for(aux1=0;aux1<10;aux1++){
					PF2=0x04;
					Delay_Variavel(0.4);
					PF2=0x00;
					Delay_Variavel(0.4);
				}
				aux1=0;
				cont++;
			break;
				//Estado 2						***DECIS�O: 5 SEGUNDOS PARA ATIVAR SW2 E IR PARA ESTADO 4, CASO N�O ATIVE IR� PARA ESTADO 3***
		case 2:
				Delay_Variavel(5);
				if(SW2==0x00)
					cont++;
				cont++;
			break;
		//Estado 3						***LED VERDE PISCA CINCO VEZES - FREQ N�O DETERMINADA, FOI ESCOLHIDA 0,4 HZ***
		case 3:
				PF1=0x00;
				PF2=0x00;
				for(aux1=0;aux1<5;aux1++){
					PF3=0x08;
					Delay_Variavel(2.5);
					PF3=0x00;
					Delay_Variavel(2.5);
				}
				cont=1;
			break;
		//Estado 4						***LED VERMELHO PISCA DUAS VEZES - FREQ N�O DETERMINADA, FOI ESCOLHIDA 0,4 HZ***
		case 4:
				PD3 = 0x00;				//Mant�m PD3 desativado
				PF2 = 0x00; 			//LED vermelho acende
				PF3 = 0x00;
				for(aux1=0;aux1<2;aux1++){
					PF1=0x02;
					Delay_Variavel(2.5);
					PF1=0x00;
					Delay_Variavel(2.5);
				}
				cont++;
			break; 
		//Estado 5 						***LED VERMELHO PISCA COM FREQU�NCIA DE 2,5 HZ***
		case 5: 
				PD3 = 0x00;				//Mant�m PD3 desativado
				PF2 = 0x00;
				PF3 = 0x00;
				for(aux1=0;aux1<10;aux1++){
					PF1 = 0x02;
					Delay_Variavel(0.4);
					PF1 = 0x00;
					Delay_Variavel(0.4);
				}
				aux1=0;
				Delay_Variavel(1);
				cont++;
			break;
		//Estado 5 						***LED VERMELHO PISCA COM FREQU�NCIA DE 2,5 HZ***
		case 6: 
				PD3 = 0x00;				//Mant�m PD3 desativado
				PF2 = 0x00;
				PF3 = 0x00;
				for(aux1=0;aux1<10;aux1++){
					PF1 = 0x02;
					Delay_Variavel(0.4);
					PF1 = 0x00;
					Delay_Variavel(0.4);
				}
				aux1=0;
				Delay_Variavel(3);
				cont++;
			break;
		//Estado 6 				***OS 3 LEDS PISCAM EM ORDEM 4 VEZES E PD3 PERMANECE ATIVADO***
		case 7:
				PD3 = 0x08;
				for(aux1=0;aux1<4;aux1++){
					PF3 = 0x00;
					PF1 = 0x02;
					Delay_Variavel(2);
					PF1 = 0x00;
					PF2 = 0x04;
					Delay_Variavel(2);
					PF2 = 0x00;
					PF3 = 0x08;
					Delay_Variavel(2);
				}
				cont=0;
			break;
	return 0;
		}
		
	}
	
}
