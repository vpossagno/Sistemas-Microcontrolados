//UTFPR
//Sistemas Microcontrolados - ET77C-S23-B
//Professor: Delvanei
//Vinicios Pereira Possagno RA: 1608002 
//Lucas Cheslak Rogge RA: 2029189

//Projeto Final - Caixa de desinfec��o de v�rus por UVC
//13/12/2021

//Este projeto foi realizado por cima do c�digo EdgeInterrupt.c disponibilizado pelo professor Valvano

// EdgeInterrupt.c
// Runs on LM4F120 or TM4C123
// Request an interrupt on the falling edge of PF4 (when the user
// button is pressed) and increment a counter in the interrupt.  Note
// that button bouncing is not addressed.
// Daniel Valvano
// May 3, 2015

/* This example accompanies the book
   "Embedded Systems: Introduction to ARM Cortex M Microcontrollers"
   ISBN: 978-1469998749, Jonathan Valvano, copyright (c) 2015
   Volume 1, Program 9.4
   
   "Embedded Systems: Real Time Interfacing to ARM Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2014
   Volume 2, Program 5.6, Section 5.5

 Copyright 2015 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */


//#include "PLL.h" //inicia o temporizador em 80 MHz
#include "Timer0A.h" 
#include "tm4c123gh6pm.h" //possui os defines j� pre-estabelecidos
#include "Systick.h"
#include <stdint.h>


#define SYSCTL_RCGC2_R          (*((volatile uint32_t *)0x400FE108))
/*
#define GPIO_PORTD_DATA_R       (*((volatile unsigned long *)0x400073FC))
#define GPIO_PORTD_DIR_R        (*((volatile unsigned long *)0x40007400))
#define GPIO_PORTD_AFSEL_R      (*((volatile unsigned long *)0x40007420))
#define GPIO_PORTD_DEN_R        (*((volatile unsigned long *)0x4000751C))
#define GPIO_PORTD_AMSEL_R      (*((volatile unsigned long *)0x40007528))
#define GPIO_PORTD_PCTL_R       (*((volatile unsigned long *)0x4000752C))*/
//********************************************************************************
// debuging profile, pick up to 7 unused bits and send to Logic Analyzer
// TExaSdisplay logic analyzer shows 5 bits 0,0,PF4,PF3,PF2,PF1,PF0 
// edit this to output which pins you use for profiling
// you can output up to 7 pins
// use for debugging profile
void LogicAnalyzerTask(void){
  UART0_DR_R = 0x80|GPIO_PORTF_DATA_R; // sends at 10kHz
}
void ScopeTask(void){  // called 10k/sec
  UART0_DR_R = (ADC1_SSFIFO3_R>>4); // send ADC to TExaSdisplay
}

//unsigned long volatile delay;

//use for debugging profile
#define PF1 (*((volatile uint32_t *)0x40025008))					//LEDS e PD1
#define PF2 (*((volatile uint32_t *)0x40025010))
#define PF3 (*((volatile uint32_t *)0x40025020))
#define PD1 (*((volatile uint32_t *)0x40007008))					//PD1 desligado � zero---PD1 ligado � 0x02
#define PF0 (*((volatile uint32_t *)0x40025001))
#define PF4 (*((volatile uint32_t *)0x40025040))	

// global variable visible in Watch window of debugger
// increments at least once per button press

unsigned long SW1, SW2;												// Vari�veis SW1 p/ PF4 e SW2 p/ PF0
static uint32_t cont=0,aux1=0; 		//vari�vel i do exerc�cio e mais variaveis auxiliares

void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void); // Enable interrupts
void WaitForInterrupt(void); // low power mode
void PortF_Init(void);


void Delay_Variavel(float var)
{
		unsigned long volatile time;
		time = var*4.546467168*727240*40/91; // Express�o para gerar delay com valor "var" em segundos
	while(time){													//Ex: se chamda Delay_Variavel(10) o delay ser� de 10 segundos
			time--;
		}
}



void atraso(void)												//Delay fixo de 0,2 segundos, pois ocorre 2 vezes. Totalizando 0,4 segundos (2,5 Hz)
{
		unsigned long volatile time;
		time = 0.9096044221*727240*40/91; // 0.2 sec
		while(time){
			time--;
		}
}



void PortD_Init(void){ unsigned long delay;
	SYSCTL_RCGCGPIO_R |= 0x00000008; // (a) activate clock for port D
	delay = SYSCTL_RCGC2_R;           // wait 3-5 bus cycles
	GPIO_PORTD_LOCK_R = 0x4C4F434B; // 2) unlock GPIO Port D
	GPIO_PORTD_CR_R = 0x1F; // allow changes to PD
	GPIO_PORTD_AMSEL_R = 0x00;  // 3) disable analog on PD
	GPIO_PORTD_PCTL_R &= ~0x000FFFFF; // configure PD as GPIO
	GPIO_PORTD_DIR_R = 0xFF; // output on PD
	GPIO_PORTD_AFSEL_R &= 0x00; // disable alt funct on PD
	GPIO_PORTD_DEN_R = 0xFF; // enable digital I/O on PD3
	GPIO_PORTD_DATA_R = 0x00;   			// PD = 0x00
}
void PortF_Init(void){
 volatile unsigned long delay;
 SYSCTL_RCGC2_R |= 0x00000020; // F clock
 delay = SYSCTL_RCGC2_R; // delay 
 GPIO_PORTF_LOCK_R = 0x4C4F434B; // unlock PortF PF0 
 GPIO_PORTF_CR_R = 0x1F; // allow changes to PF4-0 
 GPIO_PORTF_AMSEL_R = 0; // disable analog functionality on PORTF
 GPIO_PORTF_PCTL_R = 0x00000000; // configure PORTF as GPIO
 GPIO_PORTF_DIR_R |= 0x0E; // make PF0, PF4 input, PF1-PF3 output
 GPIO_PORTF_AFSEL_R &= ~0x1F; // disable alt funct 
 GPIO_PORTF_PUR_R = 0x11; // enable weak pull-up on PF4 and PF0
 GPIO_PORTF_DEN_R |= 0x1F; // enable digital I/O
}



void Timer0_Init(unsigned long period){volatile unsigned long temp;
 SYSCTL_RCGCTIMER_R |= 0x01; // 0) activate TIMER0
 temp = SYSCTL_RCGCTIMER_R; // delay
 TIMER0_CTL_R = 0x00000000; // 1) disable TIMER0A during setup
 TIMER0_CFG_R = 0x00000000; // 2) configure for 32-bit mode
 TIMER0_TAMR_R = 0x00000002; // 3) configure for periodic mode, default down-count settings
 TIMER0_TAILR_R = period-1; // 4) reload value
 TIMER0_TAPR_R = 0; // 5) bus clock resolution
 TIMER0_ICR_R = 0x00000001; // 6) clear TIMER0A timeout flag
 TIMER0_IMR_R = 0x00000001; // 7) arm timeout interrupt
 NVIC_PRI4_R = (NVIC_PRI4_R&0x00FFFFFF)|0x80000000; // 8) priority 4
// vector number 35, interrupt number 19
 NVIC_EN0_R = 1<<19; // 9) enable IRQ 19 in NVIC
 TIMER0_CTL_R = 0x00000001; // 10) enable TIMER0A
}





void Timer0A_Handler(void)
{
		volatile unsigned long delay;
		TIMER0_ICR_R = TIMER_ICR_TATOCINT; 		// acknowledge TIMER0A timeout
		if(cont==3)														//estado 3
			cont=1;															//Quando estado 3 � encerrado, retorna ao estado 1
		
		//estado 2
		SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1
		if(cont==2 && SW1==0x00)						//estado 2												
				cont=3;														//Caso SW1 esteja em n�vel baixo, contador recebe valor 3
		if(cont==2 && SW1==0x10)
			cont=4;														//Caso SW1 esteja em n�vel alto, contador recebe valor 4		
} 

void EdgeCounterPortF_Init(void){                          
  SYSCTL_RCGCGPIO_R |= 0x00000020; // (a) activate clock for port F
  cont = 0;             					// (b) initialize counter
  GPIO_PORTF_LOCK_R = 0x4C4F434B;   // 2) unlock GPIO Port F
  GPIO_PORTF_CR_R = 0x1F;           // allow changes to PF4-0
  GPIO_PORTF_DIR_R |=  0x0E;    // output on PF3,2,1 
  GPIO_PORTF_DIR_R &= ~0x11;    // (c) make PF4,0 in (built-in button)
  GPIO_PORTF_AFSEL_R &= ~0x1F;  //     disable alt funct on PF4,0
  GPIO_PORTF_DEN_R |= 0x1F;     //     enable digital I/O on PF4   
  GPIO_PORTF_PCTL_R &= ~0x000FFFFF; // configure PF4 as GPIO
  GPIO_PORTF_AMSEL_R = 0;       //     disable analog functionality on PF
  GPIO_PORTF_PUR_R |= 0x11;     //     enable weak pull-up on PF4
  GPIO_PORTF_IS_R &= ~0x10;     // (d1) PF4 is edge-sensitive
  GPIO_PORTF_IBE_R &= ~0x10;    //     PF4 is not both edges
  GPIO_PORTF_IEV_R &= ~0x10;    //     PF4 falling edge event
	GPIO_PORTF_PUR_R |= 0x11;     //     enable weak pull-up on PF4
  GPIO_PORTF_IS_R |= 0x10;     // (d2) PF0 is level-sensitive
  GPIO_PORTF_IBE_R &= ~0x10;    //     PF0 is not both edges
  GPIO_PORTF_IEV_R |= 0x10;    //     PF0 high level event
  GPIO_PORTF_ICR_R = 0x10;      // (e) clear flag4
  GPIO_PORTF_IM_R |= 0x10;      // (f) arm interrupt on PF4 *** No IME bit as mentioned in Book ***
  NVIC_PRI7_R = (NVIC_PRI7_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  NVIC_EN0_R = 0x40000000;      // (h) enable interrupt 30 in NVIC
}

void GPIOPortF_Handler(void){		//Rotina de interrup��o
  GPIO_PORTF_ICR_R = 0x10;      // acknowledge flag4
  SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1
	SW2 = ~GPIO_PORTF_DATA_R&0x01; //L� PF0 e atribui em SW2
	
		if(cont==2 && SW1==0x00)		//estado 2			
			cont=3;
		if(cont==2 && SW1==0x10)
			cont=4;												//Caso SW2 esteja em n�vel baixo, contador recebe valor 4
		
		SW2 = ~GPIO_PORTF_DATA_R&0x01; //L� PF0 e atribui em SW2
		SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1

		
		if(cont==0 && SW2==0x01)			//estado zero
		{
				cont++;
		}
		
		if(cont==7 && SW1==0x00) //estado 7
		{			
			cont=8;
			//SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1
		}
		if(cont==7 && SW1==0x10) //estado 7
		{			
			cont=2;
		}
		
		if(cont==6 && SW1==0x00)		//estado 6
		{
			GPIO_PORTF_DATA_R=0x00;														//apaga LEDs
			GPIO_PORTF_DATA_R=0x0C;														//Acende LEDs verde e azul
			Delay_Variavel(2);
			cont++;
		}
		if(cont==6 && SW1==0x10)		//estado 6
		{
			cont=1;
		}
}


//Rotina principal
int main(void){
	Timer0_Init(80000000);							//80 MHz
	PortD_Init();												//inicializa PortD
	PortF_Init(); 											// initialize PortF
	EdgeCounterPortF_Init();           // initialize GPIO Port F interrupt
	SysTick_Init(); 									//inicializa a fun��o SysTick com 200ms
	EnableInterrupts();								//Habilita interrup��o
  while(1){
		switch(cont){
		//Estado zero
		case 0:
				PF1=0x00;		//Leds desligados e PD1 em n�vel l�gico baixo
				PF2=0x00;
				PF3=0x00;
				PD1=0x00;
				GPIOPortF_Handler();
			break;
		//Estado 1
		case 1:
			//LED azul pisca uma vez
				PF2=0x04;
				Delay_Variavel(2);
				PF2=0x00;
				Delay_Variavel(2);
				PF1=0x00;		//LEDs vermelho e verde desligados e PD1 em n�vel l�gico baixo
				PF3=0x00;
				PD1=0x00;
				cont++;
			break;
		//Estado 2
		case 2:
				//Estado de decis�o baseado em PF4 (SW1)
				//PF4=0 -> cont=4 (estado 4)
				//PF4=1 -> cont=3 (estado 3)
				PF1=0x00;
				PF2=0x00;
				PF3=0x00;
				Delay_Variavel(5);
				GPIOPortF_Handler();
			break;
		//Estado 3
		case 3:
				PF3=0x08;							//LED verde pisca 5 vezes
				Delay_Variavel(5);		
				PF3=0x00;
				PF1=0x00;
				PF2=0x00;
			break;
		//Estado 4
		case 4:
				PD1 = 0x02;				//Liga rel�
				PF1 = 0x02; 			//LED vermelho acende
				Delay_Variavel(8);
				PF1 = 0x00;
				cont++;
			break; 
		//Estado 5 
		case 5: 
				PD1 =0x00;				//Desliga rel�
				for(aux1=0;aux1<6;aux1++)
				{
					PF1=0x00; 											//LED vermelho pisca
					Delay_Variavel(0.75);						//Este estado se repete
					PF1=0x02; 
					Delay_Variavel(0.75);
				}
				PF1=0x00;
				cont++;
			break;
		//Estado 6 
		case 6: 
				Delay_Variavel(5);
				GPIOPortF_Handler();
			break;
		//Estado 7 
		case 7:
				PD1	=	0x00;		//PD1 recebe n�vel l�gico baixo
				PF2 = 0x04; //led azul aceso
				PF3 = 0x00; //Led verde apagado
				Delay_Variavel(2);
				GPIOPortF_Handler();
			break;
		//Estado 8
		case 8:
			PF3 = 0x00; //leds apagados
			PF2 = 0x00;
			PF1 = 0x00;
			Delay_Variavel(0.2);
			for(aux1=0;aux1<4;aux1++)
			{
				PF3 = 0x08; //led verde 
				PF2 = 0x00;
				PF1 = 0x00;
				Delay_Variavel(0.5);
				PF1 = 0x02; //led vermelho
				PF2 = 0x00;
				PF3 = 0x00;
				Delay_Variavel(0.5);
				PF1 = 0x00;
				PF2 = 0x04; //led azul
				PF3 = 0x00;
				Delay_Variavel(0.5);
			}
			cont=0;
			break;
		
	return 0;
		}
	}	
}
