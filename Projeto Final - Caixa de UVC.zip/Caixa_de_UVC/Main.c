//UTFPR
//Sistemas Microcontrolados - ET77C-S23-B
//Professor: Delvanei
//Vinicios Pereira Possagno RA: 1608002 
//Lucas Cheslak Rogge RA: 2029189

//Projeto Semanal 3

//Este projeto foi realizado por cima do c�digo EdgeInterrupt.c disponibilizado pelo professor Valvano

// EdgeInterrupt.c
// Runs on LM4F120 or TM4C123
// Request an interrupt on the falling edge of PF4 (when the user
// button is pressed) and increment a counter in the interrupt.  Note
// that button bouncing is not addressed.
// Daniel Valvano
// May 3, 2015

/* This example accompanies the book
   "Embedded Systems: Introduction to ARM Cortex M Microcontrollers"
   ISBN: 978-1469998749, Jonathan Valvano, copyright (c) 2015
   Volume 1, Program 9.4
   
   "Embedded Systems: Real Time Interfacing to ARM Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2014
   Volume 2, Program 5.6, Section 5.5

 Copyright 2015 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */


#include "PLL.h" //inicia o temporizador em 80 MHz
#include "Timer0A.h" 
#include "tm4c123gh6pm.h" //possui os defines j� pre-estabelecidos
#include "Systick.h"
#include <stdint.h>

//********************************************************************************
// debuging profile, pick up to 7 unused bits and send to Logic Analyzer
// TExaSdisplay logic analyzer shows 5 bits 0,0,PF4,PF3,PF2,PF1,PF0 
// edit this to output which pins you use for profiling
// you can output up to 7 pins
// use for debugging profile
void LogicAnalyzerTask(void){
  UART0_DR_R = 0x80|GPIO_PORTF_DATA_R; // sends at 10kHz
}
void ScopeTask(void){  // called 10k/sec
  UART0_DR_R = (ADC1_SSFIFO3_R>>4); // send ADC to TExaSdisplay
}

#define PORTA_DATA  (*((volatile uint32_t *)0x400043FC))
#define PORTB_DATA  (*((volatile uint32_t *)0x400053FC))
#define PORTC_DATA  (*((volatile uint32_t *)0x400063FC))
#define PORTD_DATA  (*((volatile uint32_t *)0x400073FC))
#define PORTE_DATA  (*((volatile uint32_t *)0x400243FC))
#define PORTF_DATA  (*((volatile uint32_t *)0x400253FC))

//use for debugging profile
#define PF1 (*((volatile uint32_t *)0x40025008))					//LEDS e PD0
#define PF2 (*((volatile uint32_t *)0x40025010))
#define PF3 (*((volatile uint32_t *)0x40025020))
#define PD0 (*((volatile uint32_t *)0x40007004))					//PD0 desligado � zero---PD0 ligado � 1
	
#define PF0 (*((volatile uint32_t *)0x40025001))					//PF0 para SW2
#define PF4 (*((volatile uint32_t *)0x40025040))					//PF4 para SW1
	
// global variable visible in Watch window of debugger
// increments at least once per button press

unsigned long aux1;												// Vari�veis auxiliares
static uint32_t cont=0,i=0,aux2=0; 				//vari�vel i do exerc�cio e mais variaveis auxiliares

void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void); // Enable interrupts
void WaitForInterrupt(void); // low power mode
void PortF_Init(void);


void Delay_Variavel(float var)
{
		unsigned long volatile time;
		time = var*4.546467168*727240*40/91; // Express�o para gerar delay com valor "var" em segundos
	while(time){													//Ex: se chamda Delay_Variavel(10) o delay ser� de 10 segundos
			time--;
		}
}

void atraso(void)												//Delay fixo de 0,2 segundos, pois ocorre 2 vezes. Totalizando 0,4 segundos (2,5 Hz)
{
		unsigned long volatile time;
		time = 0.9096044221*727240*40/91; // 0.2 sec
		while(time){
			time--;
		}
}

void PortD_Init(void) {
	volatile unsigned long delay;

	SYSCTL_RCGC2_R |= 0x00000008; // 1) D clock
	delay = SYSCTL_RCGC2_R; // delay
	GPIO_PORTD_LOCK_R = 0x4C4F434B; // 2) unlock PortD
	GPIO_PORTD_CR_R |= 0x1F; // allow changes to PF4 (SW1) and PF2 (Blue LED)
	GPIO_PORTD_AMSEL_R = 0x00; // 3) disable analog function
	GPIO_PORTD_PCTL_R = 0x00; // 4) GPIO clear bit PCTL
	GPIO_PORTD_DIR_R &=~ 0x01; // 5) PD0 for output
	// PF2 (Blue LED) is output
	GPIO_PORTD_AFSEL_R = 0x00; // 6) no alternate function
	GPIO_PORTD_PUR_R |= 0x10; // enable pullup resistor on PF4
	GPIO_PORTD_DEN_R |= 0x01; // 7) enable digital pins PF4, PF2
}



void PortF_Init(void){
 volatile unsigned long delay;
 SYSCTL_RCGC2_R |= 0x0000028; // F clock
 delay = SYSCTL_RCGC2_R; // delay 
 GPIO_PORTF_LOCK_R = 0x4C4F434B; // unlock PortF PF0 
 GPIO_PORTF_CR_R = 0x1F; // allow changes to PF4-0 
 GPIO_PORTF_AMSEL_R = 0; // disable analog functionality on PORTF
 GPIO_PORTF_PCTL_R = 0x00000000; // configure PORTF as GPIO
 GPIO_PORTF_DIR_R |= 0x0E; // make PF0, PF4 input, PF1-PF3 output
 GPIO_PORTF_AFSEL_R &= ~0x1F; // disable alt funct 
 GPIO_PORTF_PUR_R = 0x11; // enable weak pull-up on PF4 and PF0
 GPIO_PORTF_DEN_R |= 0x1F; // enable digital I/O
}



void Timer0_Init(unsigned long period){volatile unsigned long temp;
 SYSCTL_RCGCTIMER_R |= 0x01; // 0) activate TIMER0
 temp = SYSCTL_RCGCTIMER_R; // delay
 TIMER0_CTL_R = 0x00000000; // 1) disable TIMER0A during setup
 TIMER0_CFG_R = 0x00000000; // 2) configure for 32-bit mode
 TIMER0_TAMR_R = 0x00000002; // 3) configure for periodic mode, default down-count settings
 TIMER0_TAILR_R = period-1; // 4) reload value
 TIMER0_TAPR_R = 0; // 5) bus clock resolution
 TIMER0_ICR_R = 0x00000001; // 6) clear TIMER0A timeout flag
 TIMER0_IMR_R = 0x00000001; // 7) arm timeout interrupt
 NVIC_PRI4_R = (NVIC_PRI4_R&0x00FFFFFF)|0x80000000; // 8) priority 4
// vector number 35, interrupt number 19
 NVIC_EN0_R = 1<<19; // 9) enable IRQ 19 in NVIC
 TIMER0_CTL_R = 0x00000001; // 10) enable TIMER0A
}





void Timer0A_Handler(void)
{
		volatile unsigned long delay;
		TIMER0_ICR_R = TIMER_ICR_TATOCINT; 		// acknowledge TIMER0A timeout
		if(cont==3)														//estado 3
			cont=0;															//Quando estado 3 � encerrado, retorna ao estado 1
		//estado 5
		if((cont==5 || cont==6) && aux2<2)		//estado 5 ocorre duas vezes em sequencia
		{
			aux2++;
		}
		if(cont==2 && PF0==0x00)		//estado 2												
				cont++;														//Caso SW2 esteja em n�vel alto, contador recebe valor 3
		if(cont==2 && PF0==0x01)
			cont=3;														//Caso SW2 esteja em n�vel baixo, contador recebe valor 4
		aux2=0;
		cont++;
		i=(i+1)&0xFF;													//Variavel i incrementa at� 255
		if(cont==8)														//Retorna ao estado zero
			cont=0;
} 


//Rotina principal
int main(void){
	SysTick_Init(); 									//inicializa a fun��o SysTick com 200ms
	PortD_Init();
	PortF_Init(); 										// initialize PortF
	Timer0_Init(16000000);						// 160.000.000 -> 10 segundos por estado -> Valor para facilitar aproxima��es com delays
	EnableInterrupts();
  while(1){
		switch(cont){
		//Estado zero
		case 0:
				PF1=0x00;		//Leds desligados e PD3 em n�vel l�gico baixo
				PF2=0x00;
				PF3=0x00;
				PD0=0x00;
			break;
		//Estado 1
		case 1:
			//LED azul em freq 2,5 Hz
				PF2=0x04;
				atraso();
				PF2=0x00;
				atraso();
				PF1=0x00;		//LEDs vermelho e verde desligados e PD3 em n�vel l�gico baixo
				PF3=0x00;
				PD0=0x00;
			break;
		//Estado 2
		case 2:
			//Estado de decis�o baseado em PF0 (SW2)
			//PF0=0 -> cont=4 (estado 4)
			//PF0=1 -> cont=3 (estado 3)
			break;
		//Estado 3
		case 3:
				PF3=0x08;							//LED verde pisca 5 vezes
				Delay_Variavel(1.01);	//Valor pouco maior que 1 segundo para garantir
				PF3=0x00;
				Delay_Variavel(1.01);
				PF1=0x00;
				PF2=0x00;
			break;
		//Estado 4
		case 4:
				PF1 = 0x02; 		//LED vermelho pisca duas vezes
				Delay_Variavel(2.51);
				PF1 = 0x00; 
				Delay_Variavel(2.51);
			break; 
		//Estado 5 
		case 5: 
				PF1 = 0x02; 		//LED vermelho pisca em 2,5 Hz
				atraso();				//Este estado se repete
				PF1 = 0x00; 
				atraso();
			break;
		//Estado 5 
		case 6: 
				PF1 = 0x02; 		//LED vermelho pisca em 2,5 Hz
				atraso();				//Este estado se repete
				PF1 = 0x00; 
				atraso();
			break;
		//Estado 6 
		case 7:
				PD0=0x01;		//PD3 recebe n�vel l�gico alto
				PF1 = 0x02; //led vermelho 
				PF3 = 0x00;
				Delay_Variavel(0.8334);
				PF1 = 0x00;
				PF2 = 0x04; //led azul
				Delay_Variavel(0.8334);
				PF3 = 0x08; //led verde 
				PF2 = 0x00; 
				Delay_Variavel(0.8334);
			break;
		
	return 0;
		}
	}	
}
