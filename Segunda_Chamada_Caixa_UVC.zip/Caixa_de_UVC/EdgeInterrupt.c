//UTFPR
//Sistemas Microcontrolados - ET77C-S23-B
//Professor: Delvanei
//Vinicios Pereira Possagno RA: 1608002 
//Lucas Cheslak Rogge RA: 2029189
//SEGUNDA CHAMADA
//Projeto Final - Caixa de desinfec��o de v�rus por UVC
//20/12/2021

//Este projeto foi realizado por cima do c�digo EdgeInterrupt.c disponibilizado pelo professor Valvano

// EdgeInterrupt.c
// Runs on LM4F120 or TM4C123
// Request an interrupt on the falling edge of PF4 (when the user
// button is pressed) and increment a counter in the interrupt.  Note
// that button bouncing is not addressed.
// Daniel Valvano
// May 3, 2015

/* This example accompanies the book
   "Embedded Systems: Introduction to ARM Cortex M Microcontrollers"
   ISBN: 978-1469998749, Jonathan Valvano, copyright (c) 2015
   Volume 1, Program 9.4
   
   "Embedded Systems: Real Time Interfacing to ARM Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2014
   Volume 2, Program 5.6, Section 5.5

 Copyright 2015 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

#include "tm4c123gh6pm.h" //possui os defines j� pre-estabelecidos
#include "PLL.h" //inicia o temporizador em 80 MHz
#include "Timer0A.h" 
#include <stdint.h>


#define SYSCTL_RCGC2_R          (*((volatile uint32_t *)0x400FE108))

// debuging profile, pick up to 7 unused bits and send to Logic Analyzer
// TExaSdisplay logic analyzer shows 5 bits 0,0,PF4,PF3,PF2,PF1,PF0 
// edit this to output which pins you use for profiling
// you can output up to 7 pins
// use for debugging profile
void LogicAnalyzerTask(void){
  UART0_DR_R = 0x80|GPIO_PORTF_DATA_R; // sends at 10kHz
}
void ScopeTask(void){  // called 10k/sec
  UART0_DR_R = (ADC1_SSFIFO3_R>>4); // send ADC to TExaSdisplay
}

//unsigned long volatile delay;

//use for debugging profile
#define PF1 (*((volatile uint32_t *)0x40025008))					//LEDS e PD1
#define PF2 (*((volatile uint32_t *)0x40025010))
#define PF3 (*((volatile uint32_t *)0x40025020))
#define PD1 (*((volatile uint32_t *)0x40007008))					//PD1 desligado � zero---PD1 ligado � 0x02
#define SW2 (*((volatile uint32_t *)0x40025001))
#define SW1 (*((volatile uint32_t *)0x40025040))	

// global variable visible in Watch window of debugger
// increments at least once per button press

//unsigned long SW1, SW2;												// Vari�veis SW1 p/ PF4 e SW2 p/ PF0
static uint32_t cont=0,aux1=0; 		//vari�vel i do exerc�cio e mais variaveis auxiliares

void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void); // Enable interrupts
void WaitForInterrupt(void); // low power mode
//void PortF_Init(void);

void Timer0_Init(unsigned long period){volatile unsigned long temp;
 SYSCTL_RCGCTIMER_R |= 0x01; // 0) activate TIMER0
 temp = SYSCTL_RCGCTIMER_R; // delay
 TIMER0_CTL_R = 0x00000000; // 1) disable TIMER0A during setup
 TIMER0_CFG_R = 0x00000000; // 2) configure for 32-bit mode
 TIMER0_TAMR_R = 0x00000002; // 3) configure for periodic mode, default down-count settings
 TIMER0_TAILR_R = period-1; // 4) reload value
 TIMER0_TAPR_R = 0; // 5) bus clock resolution
 TIMER0_ICR_R = 0x00000001; // 6) clear TIMER0A timeout flag
 TIMER0_IMR_R = 0x00000001; // 7) arm timeout interrupt
 NVIC_PRI4_R = (NVIC_PRI4_R&0x00FFFFFF)|0x80000000; // 8) priority 4
// vector number 35, interrupt number 19
 NVIC_EN0_R = 1<<19; // 9) enable IRQ 19 in NVIC
 TIMER0_CTL_R = 0x00000001; // 10) enable TIMER0A
}

void Delay_Variavel(float var)
{
		unsigned long volatile time;
		time = var*4.546467168*727240*40/91; // Express�o para gerar delay com valor "var" em segundos
	while(time){													//Ex: se chamda Delay_Variavel(10) o delay ser� de 10 segundos
			time--;
		}
}


void PortD_Init(void){
	//volatile unsigned long delay;
	SYSCTL_RCGCGPIO_R |= 0x00000008; // (a) activate clock for port D
	//delay = SYSCTL_RCGC2_R;           // wait 3-5 bus cycles
	GPIO_PORTD_LOCK_R = 0x4C4F434B; // 2) unlock GPIO Port D
	GPIO_PORTD_CR_R = 0x1F; // allow changes to PD
	GPIO_PORTD_AMSEL_R = 0x00;  // 3) disable analog on PD
	GPIO_PORTD_PCTL_R &= ~0x000FFFFF; // configure PD as GPIO
	GPIO_PORTD_DIR_R = 0xFF; // output on PD
	GPIO_PORTD_AFSEL_R &= 0x00; // disable alt funct on PD
	GPIO_PORTD_DEN_R = 0x1F; // enable digital I/O on PD3
	GPIO_PORTD_DATA_R = 0x00;   			// PD = 0x00
}
void PortF_Init(void){
 volatile unsigned long delay;
 SYSCTL_RCGC2_R |= 0x00000020; // F clock
 delay = SYSCTL_RCGC2_R; // delay 
 GPIO_PORTF_LOCK_R = 0x4C4F434B; // unlock PortF PF0 
 GPIO_PORTF_CR_R = 0x1F; // allow changes to PF4-0 
 GPIO_PORTF_AMSEL_R = 0; // disable analog functionality on PORTF
 GPIO_PORTF_PCTL_R = 0x00000000; // configure PORTF as GPIO
 GPIO_PORTF_DIR_R |= 0x0E; // make PF0, PF4 input, PF1-PF3 output (0x0E)h=(0000 1110)b
 GPIO_PORTF_AFSEL_R &= ~0x1F; // disable alt funct 
 GPIO_PORTF_PUR_R = 0x11; // enable weak pull-up on PF4 and PF0
 GPIO_PORTF_DEN_R |= 0x1F; // enable digital I/O
}


void Estado_oito(void){															//Fun��o do Estado 8 T=2.5 segundos repetido 4 vezes
	while(aux1<4){
		//Led verde acende e azul apaga
		PF2=0x00;
		PF3=0x08;
		Delay_Variavel(0.8334);
		PF3=0x00;		//Led vermelho acende e verde apaga
		PF1=0x02;
		Delay_Variavel(0.8334);
		PF1=0x00;		//Led azul acende e vermelho apaga
		PF2=0x04;
		Delay_Variavel(0.8334);
		aux1++;
	}
	aux1=0;
}

void GPIOPortF_Handler(void){		//Rotina de interrup��o para inicializa��o a qualquer momento que SW2 seja pressionado
  GPIO_PORTF_ICR_R = 0x10;      // acknowledge flag4
				if (SW2==0x00)					//Caso SW2 ativa cont � aumentado e c�digo come�a
					cont++;
	}
void Timer0A_Handler(void){
		//volatile unsigned long delay;
		TIMER0_ICR_R = TIMER_ICR_TATOCINT; 		// acknowledge TIMER0A timeout
		switch(cont)
		{
			//SW1 = ~GPIO_PORTF_DATA_R&0x10; //L� PF4 e atribui em SW1
			/*case 0:
				if (cont==0 && SW2==0x00)							//Caso SW2 ativa cont � aumentado
					cont++;
				break;*/
			case 1:
				cont++;
				break;
			case 2:															//estado 2
				if(SW1==0x10)											//Chave n�o pressionada cont recebe 3
					cont=3;
				if(SW1==0x00)											//Chave pressionada cont recebe 4
					cont=4;
				break;
			case 3:															//estado 3
				cont=1;															//Quando estado 3 � encerrado, retorna ao estado 1		
				break;
			case 4:
				cont++;
				break;
			case 5:
				cont++;
				break;
			case 6:
				if(SW1==0x10)											//Chave n�o pressionada cont recebe 7
					cont=7;
				if(SW1==0x00)											//Chave pressionada cont recebe 1
					cont=1;
				break;
			case 7:
				cont=8;
				break;
			case 8:
				cont=9;
				break;
			case 9:
				if(SW1==0x10)											//Chave n�o pressionada cont recebe 10
					cont=10;
				if(SW1==0x00)											//Chave pressionada cont recebe 2
					cont=2;
				break;
			case 10:
					cont=11;
				break;
			case 11:
					cont=0;
				break;
		}
} 

//Rotina principal
int main(void){
	volatile unsigned long delay;
	
	PLL_Init(Bus16MHz);									//16 MHz
	PortF_Init(); 											// initialize PortF
	PortD_Init();												//inicializa PortD

	GPIOPortF_Handler();
	
	Timer0_Init(80000000);						//5 segundos para cada estado diferente de zero	
	EnableInterrupts();								//Habilita interrup��o
  while(1){
		switch(cont){
		//Estado zero
		case 0:
				PF1=0x00;		//Leds desligados e PD1 em n�vel l�gico baixo
				PF2=0x00;
				PF3=0x00;
				PD1=0x00;
				GPIOPortF_Handler();
			break;
		//Estado 1
		case 1:
			//LED azul pisca uma vez
				PF1=0x00;		//LEDs vermelho e verde desligados e PD1 em n�vel l�gico baixo
				PF3=0x00;
				PD1=0x00;
				PF2=0x04;
				Delay_Variavel(3);
				PF2=0x00;
				Delay_Variavel(3);

				//cont++;
			break;
		//Estado 2
		case 2:
				PF2=0x00;
				//Estado de decis�o baseado em PF4 (SW1)
				//PF4=0 -> cont=4 (estado 4)
				//PF4=1 -> cont=3 (estado 3)
				//PF1=0x00;
				//PF2=0x00;
				//PF3=0x00;
				//Delay_Variavel(5);
				//GPIOPortF_Handler();
			break;
		//Estado 3
		case 3:
				PF3=0x08;							//LED acende durante 5 segundos
				Delay_Variavel(5);		
				PF3=0x00;
				PF1=0x00;
				PF2=0x00;
				Delay_Variavel(0.1);
			break;
		//Estado 4
		case 4:
				PD1 = 0x02;				//Liga rel�
				PF1 = 0x02; 			//LED vermelho acende
				Delay_Variavel(8);
				PF1 = 0x00;
				//cont++;
			break; 
		//Estado 5 
		case 5: 
				PD1 =0x00;				//Desliga rel�
				for(aux1=0;aux1<6;aux1++)
				{
					PF1=0x00; 											//LED vermelho pisca
					Delay_Variavel(0.75);						//Este estado se repete
					PF1=0x02; 
					Delay_Variavel(0.75);
				}
				PF1=0x00;
				//cont++;
			break;
		//Estado 6 
		case 6: 
				//Tempo para decis�o do usu�rio
				//GPIOPortF_Handler();
			break;
		//Estado 7 
		case 7:
				PF1 = 0x00;
				PF2 = 0x04; //led azul
				PF3 = 0x08; //led verde
			break;
		//Estado 8
		case 8:
			PF3 = 0x00; //leds apagados			
			//cont=0;
			break;
		case 9:
			//Decis�o
			break;
		case 10:
				PF1=0x00;		//Leds desligados
				PF2=0x00;
				PF3=0x00;
			break;
		case 11:
				Estado_oito();
			break;
		
	return 0;
		}
	}	
}
